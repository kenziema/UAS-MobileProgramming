package com.UAS.uasmobprog;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.UAS.uasmobprog.model.MoviePage;
import com.UAS.uasmobprog.model.Result;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private CustomAdapter customAdapter;
    String API_KEY = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlMDg4NmMzZjllNDE4YjlhYTE2YmJhMjNjN2NkM2QxNSIsInN1YiI6IjYzZGZiMjc0ZTU1OTM3MDA4M2E1M2Q1OSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.C0kX7Sfc7JgqyDbblGVW25N1QWIJa2-kUYH-YrE2eEg";
    String LANGUAGE = "en-US";
    String CATEGORY = "popular";
    int PAGE = 1;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);


        ApiInterface apiInterface = APIClient.getRetrofitInstance().create(ApiInterface.class);
        Call<MoviePage> call = apiInterface.getMovie(CATEGORY, API_KEY, LANGUAGE, PAGE);
        call.enqueue(new Callback<MoviePage>() {
            @Override
            public void onResponse(Call<MoviePage> call,Response<MoviePage> response) {

                List<Result> movieList = response.body().getResults();
                customAdapter = new CustomAdapter(MainActivity.this, movieList);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setAdapter(customAdapter);
            }

            @Override
            public void onFailure(Call<MoviePage> call,Throwable t) {

            }
        });
    }









}